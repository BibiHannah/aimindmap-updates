# Notices

**AI MindMap Builder** — Copyright (c) 2026 BibiHannah. All rights reserved. See `LICENSE`.

## Third-party software
Open-source components and their licences are listed in `THIRD_PARTY_LICENSES.txt`
(regenerate it with `node scripts/gen-licenses.cjs` after changing dependencies).

## Original work
The application icon and logo (`native/icon/`) and the interface text are original work
of the copyright holder. Third-party code is limited to the components listed above.

## Data and privacy
Documents are stored on the user's computer (in the app's local storage and in files the
user chooses). The app sends nothing anywhere except: (1) AI requests, to the service the
user selects and with the user's own key or sign-in; (2) update checks, to the address
built into the app, which receive no document content.
