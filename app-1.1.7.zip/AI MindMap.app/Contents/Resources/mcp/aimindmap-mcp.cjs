#!/usr/bin/env node
// MCP server for AI MindMap (stdio, no dependencies).
// Lets Claude Desktop, Claude Code, Codex and other MCP clients create mind maps that open in the app.
//   node aimindmap-mcp.cjs
// Maps are written to ~/Documents/AI MindMap (override with AIMINDMAP_DIR) and opened with the app.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');

const DIR = process.env.AIMINDMAP_DIR || path.join(os.homedir(), 'Documents', 'AI MindMap');
const APP = process.env.AIMINDMAP_APP || 'AI MindMap';
const LAYOUTS = {
  auto: 'branches balanced left and right (default)', right: 'all branches to the right', left: 'all branches to the left',
  radial: 'branches spread evenly around the centre; good for many branches', quad: 'four quadrants; best with exactly 4 main branches',
  tree: 'grows upward like a tree with tapering branches', family: 'family tree, top-down with soft branches',
  down: 'org chart, top-down', up: 'bottom-up', list: 'indented outline list',
};
const OUTLINE_HELP = 'Plain text, one topic per line, two spaces of indentation per level, each line starting with "- ". '
  + 'Do not include the centre topic (that is "title"). Short phrases; 4-7 main branches with 2-5 sub-topics each works best. Example:\n- Goals\n  - Revenue\n  - Users\n- Risks\n  - Schedule';

const TOOLS = [
  {
    name: 'create_mindmap',
    description: 'Create a new mind map and open it in the AI MindMap app on this Mac. Never overwrites existing maps. Returns the saved file path.',
    inputSchema: {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Centre topic of the map.' },
        outline: { type: 'string', description: OUTLINE_HELP },
        layout: { type: 'string', enum: Object.keys(LAYOUTS), description: Object.entries(LAYOUTS).map(([k, v]) => `${k}: ${v}`).join('; ') },
        open: { type: 'boolean', description: 'Open in the app right away (default true).' },
      },
      required: ['title', 'outline'],
    },
  },
  {
    name: 'list_mindmaps',
    description: 'List mind map files in the AI MindMap documents folder (maps created by this tool and maps the user saved there).',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'read_mindmap',
    description: 'Read a mind map file (saved from the app, or created by this tool) and return it as an indented text outline.',
    inputSchema: { type: 'object', properties: { path: { type: 'string', description: 'Absolute path of the .json file.' } }, required: ['path'] },
  },
];

function safeName(title) {
  return String(title).replace(/[\/\\:*?"<>|\n\r\t]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60) || 'mindmap';
}

function createMindmap(args) {
  const title = String(args.title || '').trim();
  const outline = String(args.outline || '').trim();
  if (!title) throw new Error('title is required');
  if (!outline) throw new Error('outline is required');
  const layout = Object.prototype.hasOwnProperty.call(LAYOUTS, args.layout) ? args.layout : 'auto';
  fs.mkdirSync(DIR, { recursive: true });
  let file = path.join(DIR, `${safeName(title)}.outline.json`);
  for (let i = 2; fs.existsSync(file); i += 1) file = path.join(DIR, `${safeName(title)} ${i}.outline.json`);
  fs.writeFileSync(file, JSON.stringify({ format: 'aimindmap-outline', title, layout, outline }, null, 2));
  const topics = outline.split('\n').filter(l => l.trim()).length + 1;
  if (args.open === false) return Promise.resolve(`Saved ${topics} topics to ${file} (not opened).`);
  return new Promise(resolve => {
    execFile('open', ['-a', APP, file], err => resolve(err
      ? `Saved ${topics} topics to ${file}, but could not open the AI MindMap app (${err.message.trim()}). The user can open the file from the app with ⌘O.`
      : `Created a mind map with ${topics} topics and opened it in AI MindMap as a new document. File: ${file}`));
  });
}

function listMindmaps() {
  if (!fs.existsSync(DIR)) return `No maps yet. Folder: ${DIR}`;
  const files = fs.readdirSync(DIR).filter(f => f.endsWith('.json'))
    .map(f => ({ f, t: fs.statSync(path.join(DIR, f)).mtimeMs })).sort((a, b) => b.t - a.t).slice(0, 100);
  return files.length ? files.map(x => `${path.join(DIR, x.f)}\t${new Date(x.t).toISOString().slice(0, 16)}`).join('\n') : `No maps yet. Folder: ${DIR}`;
}

function readMindmap(args) {
  const file = String(args.path || '');
  if (!path.isAbsolute(file) || !file.endsWith('.json')) throw new Error('path must be an absolute path to a .json file');
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (data && data.format === 'aimindmap-outline') return `${data.title}\n${typeof data.outline === 'string' ? data.outline : JSON.stringify(data.outline)}`;
  if (!data || typeof data.topics !== 'object' || !Array.isArray(data.roots)) throw new Error('not an AI MindMap file');
  const lines = [];
  const walk = (id, depth) => {
    const t = data.topics[id];
    if (!t || lines.length > 3000) return;
    lines.push(`${'  '.repeat(depth)}- ${String(t.text).replace(/\n/g, ' ')}${t.note ? `  (note: ${String(t.note).replace(/\n/g, ' ').slice(0, 200)})` : ''}`);
    (t.children || []).forEach(c => walk(c, depth + 1));
  };
  data.roots.forEach(r => walk(r, 0));
  return `layout: ${data.layout || 'auto'}\n${lines.join('\n')}`;
}

async function callTool(name, args) {
  if (name === 'create_mindmap') return createMindmap(args || {});
  if (name === 'list_mindmaps') return listMindmaps();
  if (name === 'read_mindmap') return readMindmap(args || {});
  throw new Error(`unknown tool: ${name}`);
}

const send = msg => process.stdout.write(`${JSON.stringify(msg)}\n`);

async function handle(msg) {
  const { id, method, params } = msg;
  if (id === undefined || id === null) return; // notification
  try {
    if (method === 'initialize') {
      return send({ jsonrpc: '2.0', id, result: {
        protocolVersion: (params && params.protocolVersion) || '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: 'aimindmap', version: '1.0.0' },
        instructions: 'Use create_mindmap to turn a topic, notes or a plan into a mind map that opens in the AI MindMap app. Write topics in the user\'s language.',
      } });
    }
    if (method === 'ping') return send({ jsonrpc: '2.0', id, result: {} });
    if (method === 'tools/list') return send({ jsonrpc: '2.0', id, result: { tools: TOOLS } });
    if (method === 'tools/call') {
      try {
        const text = await callTool(params && params.name, params && params.arguments);
        return send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text }] } });
      } catch (e) {
        return send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: `Error: ${e.message}` }], isError: true } });
      }
    }
    send({ jsonrpc: '2.0', id, error: { code: -32601, message: `Method not found: ${method}` } });
  } catch (e) {
    send({ jsonrpc: '2.0', id, error: { code: -32603, message: e.message } });
  }
}

let buffer = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => {
  buffer += chunk;
  let i;
  while ((i = buffer.indexOf('\n')) >= 0) {
    const line = buffer.slice(0, i).trim();
    buffer = buffer.slice(i + 1);
    if (!line) continue;
    try { void handle(JSON.parse(line)); } catch { /* ignore malformed input */ }
  }
});
